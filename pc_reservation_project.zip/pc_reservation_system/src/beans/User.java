package beans;

public class User {

}
